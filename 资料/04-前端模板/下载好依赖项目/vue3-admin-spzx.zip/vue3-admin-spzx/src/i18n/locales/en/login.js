export default {
  username: 'Username',
  password: 'Password',
  login: 'Login',
  logining: 'Login...',
  loginsuccess: 'Success',
  'rules-username': 'Please input username',
  'rules-password': 'Please input password',
  'rules-regpassword': '6 to 12 characters in length',
}
